#soal 1
def tambah(a, b):
    return a + b
a = 5
b = 10

penjumlahan = a + b

print("hasil penjumlahan =",penjumlahan)

#soal 2
def kurang(a, b):
    return a - b
a = 5
b = 10

pengurangan = a - b
print("hasil pengurangan =",pengurangan)
#soal 3
def perkalian(a, b):
    return a * b

#soal 4
def pembagian(a, b):
    if b == 0:
        print("pesan error")

#soal 5
def modulus(a, b):
    return a % b

#soal 6




    

